<!DOCTYPE html>
<html lang="id">
<head>
    <title>Tentang Kami</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Tentang Kami</h1>
    <p>DonatShop adalah toko donat online yang menyediakan donat dengan berbagai rasa dan topping.</p>
</div>
</body>
</html>
