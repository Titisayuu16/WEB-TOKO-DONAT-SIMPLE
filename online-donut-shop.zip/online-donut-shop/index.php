<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>DonatShop - Beranda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Selamat Datang di DonatShop!</h1>
    <p>Kami menjual berbagai macam donat lezat dan fresh setiap hari.</p>
    <a href="produk.php" class="btn btn-primary">Lihat Produk</a>
</div>
</body>
</html>
