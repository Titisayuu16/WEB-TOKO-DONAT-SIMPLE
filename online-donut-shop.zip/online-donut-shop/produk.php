<?php
include 'config.php';
session_start();
$result = $conn->query("SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Produk Donat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Daftar Produk</h1>
    <div class="row">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-md-4">
                <div class="card mb-3">
                    <img src="assets/images/<?= $row['gambar'] ?>" class="card-img-top img-fluid" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['nama']) ?></h5>
                        <p class="card-text">Rp<?= number_format($row['harga'], 0, ',', '.') ?></p>
                        <a href="tambah_keranjang.php?id=<?= $row['id'] ?>" class="btn btn-success">Tambah ke Keranjang</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <a href="keranjang.php" class="btn btn-primary">Lihat Keranjang</a>
</div>
</body>
</html>
