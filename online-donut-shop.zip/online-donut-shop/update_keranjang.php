<?php
session_start();
$id = $_GET['id'];
$aksi = $_GET['aksi'];

if ($aksi == "tambah") {
    $_SESSION['keranjang'][$id]++;
} elseif ($aksi == "kurang") {
    if ($_SESSION['keranjang'][$id] > 1) {
        $_SESSION['keranjang'][$id]--;
    } else {
        unset($_SESSION['keranjang'][$id]);
    }
}

header("Location: keranjang.php");
exit;
