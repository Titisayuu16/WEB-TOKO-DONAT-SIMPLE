<?php
include 'config.php';
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Keranjang Anda</h1>
    <table class="table table-bordered">
        <tr>
            <th>Produk</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Total</th>
            <th>Aksi</th>
        </tr>

        <?php
        $total = 0;
        if (isset($_SESSION['keranjang']) && !empty($_SESSION['keranjang'])):
            foreach ($_SESSION['keranjang'] as $id => $jumlah):
                $result = $conn->query("SELECT * FROM produk WHERE id=$id");
                $produk = $result->fetch_assoc();
                $subtotal = $produk['harga'] * $jumlah;
                $total += $subtotal;
        ?>
            <tr>
                <td><?= $produk['nama'] ?></td>
                <td>
                    <a href="update_keranjang.php?id=<?= $id ?>&aksi=kurang" class="btn btn-warning btn-sm">-</a>
                    <?= $jumlah ?>
                    <a href="update_keranjang.php?id=<?= $id ?>&aksi=tambah" class="btn btn-success btn-sm">+</a>
                </td>
                <td>Rp<?= number_format($produk['harga'], 0, ',', '.') ?></td>
                <td>Rp<?= number_format($subtotal, 0, ',', '.') ?></td>
                <td><a href="hapus_keranjang.php?id=<?= $id ?>" class="btn btn-danger btn-sm">Hapus</a></td>
            </tr>
        <?php
            endforeach;
        ?>
            <tr>
                <th colspan="3">Total</th>
                <th colspan="2">Rp<?= number_format($total, 0, ',', '.') ?></th>
            </tr>
        <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">Keranjang masih kosong.</td>
            </tr>
        <?php endif; ?>
    </table>

    <a href="produk.php" class="btn btn-primary">Kembali ke Produk</a>
    <?php if (!empty($_SESSION['keranjang'])): ?>
        <a href="checkout.php" class="btn btn-success">Checkout</a>
    <?php endif; ?>
</div>
</body>
</html>
