<?php
session_start();
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
unset($_SESSION['keranjang']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Terima Kasih</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Terima Kasih, <?= htmlspecialchars($nama) ?>!</h1>
    <p>Pesanan Anda akan dikirim ke: <?= htmlspecialchars($alamat) ?></p>
</div>
</body>
</html>
