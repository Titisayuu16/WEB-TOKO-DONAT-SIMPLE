<?php
include 'config.php';
session_start();

// Jika keranjang kosong, redirect
if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {
    header("Location: keranjang.php");
    exit;
}

// Hitung total
$total = 0;
foreach ($_SESSION['keranjang'] as $id => $jumlah) {
    $result = $conn->query("SELECT * FROM produk WHERE id=$id");
    $produk = $result->fetch_assoc();
    $total += $produk['harga'] * $jumlah;
}

// Simpan ke tabel pesanan
$conn->query("INSERT INTO pesanan (total) VALUES ($total)");
$pesanan_id = $conn->insert_id;

// Simpan ke tabel pesanan_detail
foreach ($_SESSION['keranjang'] as $id => $jumlah) {
    $result = $conn->query("SELECT * FROM produk WHERE id=$id");
    $produk = $result->fetch_assoc();
    $harga = $produk['harga'];

    $conn->query("INSERT INTO pesanan_detail (pesanan_id, produk_id, jumlah, harga)
                  VALUES ($pesanan_id, $id, $jumlah, $harga)");
}

// Kosongkan keranjang
unset($_SESSION['keranjang']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Checkout Selesai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h1>Terima kasih!</h1>
    <p>Pesanan Anda telah diproses. Nomor pesanan: <strong>#<?= $pesanan_id ?></strong></p>
    <a href="produk.php" class="btn btn-primary">Kembali ke Produk</a>
</div>
</body>
</html>
